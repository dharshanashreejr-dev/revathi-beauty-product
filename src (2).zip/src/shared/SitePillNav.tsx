import { useMemo, type ComponentType } from 'react'
import PillNav from './reactbits/PillNav'
import './site-pill-nav.css'

// React Bits PillNav used for the website navbar (Landing + every other page).
// `Link` is the page's own link component (router link on the app pages, plain <a> on the landing page).
type LinkLike = ComponentType<any>
export type PillItem = { key: string; label: string; href: string }

export default function SitePillNav({ items, current, Link, label }: { items: PillItem[]; current?: string; Link?: LinkLike; label?: string }) {
  const A = useMemo(() => {
    if (!Link) return 'a' as unknown as LinkLike
    const Adapter = ({ href, ...rest }: { href: string }) => <Link to={href} {...rest} />
    return Adapter as LinkLike
  }, [Link])
  const active = items.find((i) => i.key === current)?.href
  return (
    <PillNav
      items={items.map(({ label: l, href }) => ({ label: l, href }))}
      activeHref={active ?? '\u0000none'}
      linkComponent={A}
      layout="joined"
      surface="glass"
      itemStyle="plain"
      hoverEffect="fill"
      indicator="dot"
      size="sm"
      collapse="never"
      intro={false}
      theme="dark"
      barColor="rgba(73, 28, 141, 0.5)"
      textColor="#f5f2fd"
      highlightColor="#f5f2fd"
      highlightTextColor="#4c1d92"
      ariaLabel={label ?? 'Site pages'}
      className="site-pill-nav"
    />
  )
}
