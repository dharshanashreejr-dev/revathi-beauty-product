/** @type {import('tailwindcss').Config} */
export default {
  content: ['./site/index.html', './src/site/**/*.{ts,tsx}'],
  theme: { extend: { colors: { sand: '#faf7f0', ink: '#1f2d24', stone: '#2c3a31', gold: '#c9a96a' },
    fontFamily: { sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'], display: ['Outfit', 'system-ui', 'sans-serif'] } } },
  plugins: [],
}
